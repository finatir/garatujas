const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json()); 


const db = new sqlite3.Database('./organiza_fio.db', (err) => {
    if (err) {
        console.error('Erro ao abrir o banco de dados:', err.message);
    } else {
        console.log('Conectado ao banco de dados SQLite.');
        db.serialize(() => {
            
            db.run(`CREATE TABLE IF NOT EXISTS Usuarios (
                id_usuario INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                senha_hash TEXT NOT NULL
            )`);
         
            db.run(`CREATE TABLE IF NOT EXISTS Pedidos (
                id_pedido INTEGER PRIMARY KEY AUTOINCREMENT,
                nome_cliente TEXT NOT NULL,
                peca TEXT NOT NULL,
                cores TEXT,
                medidas TEXT,
                prazo_entrega DATE,
                status TEXT NOT NULL
            )`);

            const hashedPassword = bcrypt.hashSync('123456', 10);
            db.run(`INSERT OR IGNORE INTO Usuarios (username, senha_hash) VALUES (?, ?)`, 
                ['admin', hashedPassword], 
                (err) => {
                    if (err) console.error("Erro ao inserir usuário padrão:", err.message);
                    else console.log("Usuário padrão 'admin' criado (senha: 123456) ou já existe.");
                }
            );
        });
    }
});



app.post('/api/pedidos', (req, res) => {
    const { cliente, peca, cores, medidas, prazo, status } = req.body;

    if (!cliente || !peca || !status) {
        return res.status(400).json({ error: 'Os campos Cliente, Peça e Status são obrigatórios.' });
    }

    const sql = `INSERT INTO Pedidos (nome_cliente, peca, cores, medidas, prazo_entrega, status) VALUES (?, ?, ?, ?, ?, ?)`;
    const params = [cliente, peca, cores, medidas, prazo, status];

    db.run(sql, params, function(err) {
        if (err) {
            console.error(err.message);
            return res.status(500).json({ error: 'Erro ao salvar o pedido no banco de dados.' });
        }
        res.status(201).json({ 
            message: 'Pedido salvo com sucesso!', 
            id_pedido: this.lastID 
        });
    });
});

app.get('/api/pedidos', (req, res) => {
    const sql = `SELECT * FROM Pedidos ORDER BY prazo_entrega ASC`;
    
    db.all(sql, [], (err, rows) => {
        if (err) {
            console.error(err.message);
            return res.status(500).json({ error: 'Erro ao buscar pedidos.' });
        }
        res.json(rows);
    });
});


app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Usuário e senha são obrigatórios.' });
    }

    db.get(`SELECT senha_hash FROM Usuarios WHERE username = ?`, [username], async (err, row) => {
        if (err) {
            console.error(err.message);
            return res.status(500).json({ error: 'Erro interno do servidor.' });
        }
        
        if (!row) {
            return res.status(401).json({ message: 'Usuário ou senha inválidos.' });
        }

        const match = await bcrypt.compare(password, row.senha_hash);
        
        if (match) {
            res.json({ success: true, message: 'Login realizado com sucesso!' });
        } else {
            res.status(401).json({ success: false, message: 'Usuário ou senha inválidos.' });
        }
    });
});

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
    console.log(`Rotas de API prontas para uso.`);
});