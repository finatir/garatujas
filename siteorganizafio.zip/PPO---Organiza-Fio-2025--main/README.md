# PPO---Organiza-Fio-2025-

Para o funcionamento do projeto utilizar em terminal os seguintes comandos: 
1)  node -v
     npm -v

2) cd backend

3) npm install

4) node server.js
