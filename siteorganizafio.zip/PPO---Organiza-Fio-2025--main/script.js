

document.addEventListener('DOMContentLoaded', () => {
 
    const API_URL = 'http://localhost:3000/api'; 
    
 
    const formLogin = document.getElementById('form-login');
    const loginSection = document.getElementById('login-form');
    const mainContent = document.querySelector('main');
    const loginMessage = document.getElementById('login-message');

    const formPedido = document.getElementById('form-pedido');
    const listaPedidosBody = document.getElementById('lista-pedidos');

    
    async function carregarPedidos() {
        try {
            const response = await fetch(`${API_URL}/pedidos`);
            if (!response.ok) {
            
                throw new Error('Erro ao buscar os pedidos da API.');
            }
            const pedidos = await response.json();
            
            listaPedidosBody.innerHTML = ''; 
            
            if (pedidos.length === 0) {
                 listaPedidosBody.innerHTML = '<tr><td colspan="5">Nenhum pedido cadastrado ainda.</td></tr>';
                 return;
            }
            
            pedidos.forEach(pedido => {
                const tr = document.createElement('tr');
                
            
                const prazoFormatado = new Date(pedido.prazo_entrega).toLocaleDateString('pt-BR');

                tr.innerHTML = `
                    <td>${pedido.nome_cliente}</td>
                    <td>${pedido.peca}</td>
                    <td>${prazoFormatado}</td>
                    <td>${pedido.status}</td>
                    <td><button class="btn-acao" data-id="${pedido.id_pedido}">Detalhes/Ações</button></td>
                `;
                listaPedidosBody.appendChild(tr);
            });

        } catch (error) {
            console.error('Falha ao carregar pedidos:', error);
            listaPedidosBody.innerHTML = '<tr><td colspan="5">Erro ao carregar pedidos. Verifique se o servidor está rodando.</td></tr>';
        }
    }


  
    formLogin.addEventListener('submit', async (e) => {
        e.preventDefault();

        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        loginMessage.textContent = ''; 

        try {
            const response = await fetch(`${API_URL}/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password }),
            });

            const data = await response.json();

            if (response.ok && data.success) {
                
                alert('Login realizado com sucesso! Bem-vindo(a).');
                
     
                loginSection.style.display = 'none';
                mainContent.style.display = 'block';

            
                carregarPedidos(); 

            } else {
            
                loginMessage.textContent = data.message || 'Erro de autenticação desconhecido.';
            }

        } catch (error) {
            console.error('Erro de rede durante o login:', error);
            loginMessage.textContent = 'Não foi possível conectar ao servidor. Verifique a porta 3000.';
        }
    });


   
    formPedido.addEventListener('submit', async (e) => {
        e.preventDefault();

        const novoPedido = {
            cliente: document.getElementById('cliente').value,
            peca: document.getElementById('peca').value,
            cores: document.getElementById('cores').value,
            medidas: document.getElementById('medidas').value,
            prazo: document.getElementById('prazo').value,
            status: document.getElementById('status').value,
        };

        try {
       
            const response = await fetch(`${API_URL}/pedidos`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(novoPedido),
            });

            const data = await response.json();

            if (response.ok) {
                alert('Pedido salvo com sucesso! ID: ' + data.id_pedido);
                formPedido.reset(); 
                carregarPedidos();
            } else {
                alert(`Erro ao salvar: ${data.error}`);
            }

        } catch (error) {
            console.error('Erro de rede ao salvar o pedido:', error);
            alert('Não foi possível conectar ao servidor. Verifique o console.');
        }
    });


});